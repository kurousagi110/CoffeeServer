var express = require("express");
var router = express.Router();
const AuthenWeb = require("../../components/MiddleWare/AuthenWeb");
const chiNhanhController = require("../../components/ChiNhanh/ControllerChiNhanh");
const jwt = require("jsonwebtoken");
const upload = require("../../components/MiddleWare/uploadMultiFile");
const loaiSanPhamController = require("../../components/LoaiSanPham/ControllerLoaiSanPham");
const toppingService = require("../../components/Topping/ServiceTopping");
const Swal = require("sweetalert2");
const { uploadImageToS3 } = require('../cpanel/uploadImageToS3FromClient');
const {
  addNotificationToAllUser,
  sendNotificationNewProduct,
} = require("../../components/Notification/ServiceNotification");


//hien thi trang topping
router.get("/", [AuthenWeb], async (req, res) => {
  let listTopping = await toppingService.layTatCaTopping();
  let stt = 1;
    for (let i = 0; i < listTopping.length; i++) {
        listTopping[i].stt = stt;
        stt++;
    }
  res.render("topping/topping", { listTopping });
});












module.exports = router;