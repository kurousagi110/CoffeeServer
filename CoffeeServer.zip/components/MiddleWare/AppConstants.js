const ROLES ={
    USER: 1,
    ADMIN: 100,
    SYSTEM : 10
}

module.exports = { ROLES }