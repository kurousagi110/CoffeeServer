export const trang_thai_don_hang = {
  da_huy: 0,
  cho_xac_nhan: 1,
  da_xac_nhan: 2,
  dang_giao: 3,
  da_giao: 4,
  da_danh_gia: 5,
};
